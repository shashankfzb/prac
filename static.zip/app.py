

from flask import Flask, render_template, request, jsonify, redirect, url_for, session
import google.generativeai as genai
import langdetect  
from pymongo import MongoClient
from datetime import datetime
import pytz
import os
from werkzeug.security import generate_password_hash, check_password_hash

app = Flask(__name__)
app.secret_key = "your_secret_key"  # Set a secret key for session management

client = MongoClient("mongodb+srv://sahil_shelke:LGDKmRZtggGHEICA@cluster0.zylg3.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0") # Add your MongoDB connection string here
db = client.chat_db
chats_collection = db.chats 
user_collection = db.users  # User collection for authentication
ist = pytz.timezone('Asia/Kolkata')

# Test the MongoDB connection
try:
    client.admin.command('ping')  # Ping the server to check connection
    print("Connected to MongoDB")
except Exception as e:
    print(f"Failed to connect to MongoDB: {e}")

genai.configure(api_key="AIzaSyDt7zOSjL6dlZjwvCOrtZetF2GM3YOnbpc")  
generation_config = {
    "temperature": 2,
    "top_p": 0.95,
    "top_k": 64,
    "max_output_tokens": 8192,
    "response_mime_type": "text/plain",
}

marathi_model = genai.GenerativeModel(
    model_name="gemini-1.5-pro",
    generation_config=generation_config,
    system_instruction="कृपया लक्षात घ्या की या मॉडेलने वापरकर्त्याच्या प्रश्नांची उत्तरे मराठीत देणे अपेक्षित आहे. जर वापरकर्ता कृषीशी संबंधित प्रश्न विचारत असेल, तर त्यास यथाशक्ती उत्तर द्या. जर वापरकर्ता अन्य कोणत्याही प्रकारचे प्रश्न विचारत असेल, तर उत्तर द्या: 'माफ करा, मी फक्त कृषीशी संबंधित प्रश्नांची उत्तरे देऊ शकतो.'"
)

hindi_model = genai.GenerativeModel(
    model_name="gemini-1.5-pro",
    generation_config=generation_config,
    system_instruction="कृपया ध्यान दें कि इस मॉडल को उपयोगकर्ता के प्रश्नों का उत्तर हिंदी में देना है। यदि उपयोगकर्ता कृषि से संबंधित प्रश्न पूछता है, तो जितना संभव हो उतना उत्तर दें। यदि उपयोगकर्ता किसी अन्य प्रकार का प्रश्न पूछता है, तो उत्तर दें: 'मुझे खेद है, मैं केवल कृषि से संबंधित प्रश्नों का उत्तर दे सकता हूं।'"
)

english_model = genai.GenerativeModel(
    model_name="gemini-1.5-pro",
    generation_config=generation_config,
    system_instruction="Please answer the user's questions in English. If the user asks about agriculture, weather, or farming, provide a relevant response. If the user asks non-agriculture-related questions, respond with: 'Sorry, I can only answer questions related to agriculture.'"
)

@app.route('/')
def index():
    if 'user_id' in session:
        return render_template('index.html', username=session['username'])
    return redirect(url_for('login'))

@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        hashed_password = generate_password_hash(password)

        # Check if the username already exists
        if user_collection.find_one({'username': username}):
            return 'Username already exists!'

        # Insert the new user
        user_collection.insert_one({
            'username': username,
            'password': hashed_password
        })
        return redirect(url_for('login'))
    return render_template('register.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']

        user = user_collection.find_one({'username': username})

        if user and check_password_hash(user['password'], password):
            session['user_id'] = str(user['_id'])  # Store user ID in session
            session['username'] = username  # Store username in session
            return redirect(url_for('index'))

        return 'Invalid username or password!'
    return render_template('login.html')

@app.route('/logout', methods=['GET'])
def logout():
    session.pop('user_id', None)  # Remove user ID from session
    session.pop('username', None)  # Remove username from session
    return jsonify({'message': 'Logged out successfully'})

@app.route('/ask', methods=['POST'])
def ask():
    data = request.json
    question = data.get('question', '')
    username = session.get('username')  # Get the logged-in username

    if username is None:
        return jsonify({'error': 'User not logged in.'}), 401  # Handle case where user is not logged in

    try:
        detected_language = langdetect.detect(question)
    except Exception as e:
        print(f"Error detecting language: {e}")
        detected_language = 'en'

    # Generate response based on detected language
    if detected_language == 'mr':
        response = marathi_model.start_chat().send_message(question)
    elif detected_language == 'hi':
        response = hindi_model.start_chat().send_message(question)
    else:
        response = english_model.start_chat().send_message(question)

    chat_data = {
        "user_input": question,
        "system_response": response.text,
        "language": detected_language,
        "timestamp": datetime.now(ist),
        "username": username,  # Store logged-in user's username
        "sessionid": "1"
    }

    # Attempt to insert the chat data into MongoDB
    try:
        result = chats_collection.insert_one(chat_data)
        print(f"Chat data inserted with id: {result.inserted_id}")  # Debug log
    except Exception as e:
        print(f"Error inserting chat data: {e}")  # Catch and print any errors

    return jsonify({'response': response.text})

if __name__ == '__main__':
    app.run(debug=True)
